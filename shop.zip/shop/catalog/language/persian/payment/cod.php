<?php
// Text
$_['text_title'] = 'پرداخت وجه هنگام تحویل';
?>