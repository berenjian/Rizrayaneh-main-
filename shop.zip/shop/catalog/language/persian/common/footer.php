<?php
// Text
$_['text_information']  = 'اطلاعات';
$_['text_service']      = 'خدمات مشتریان';
$_['text_extra']        = 'موارد اضافی';
$_['text_contact']      = 'تماس با ما';
$_['text_return']       = 'استرداد کالا';
$_['text_sitemap']      = 'نقشه سایت';
$_['text_manufacturer'] = 'تولید کنندگان';
$_['text_voucher']      = 'کارت هدیه';
$_['text_affiliate']    = 'بازاریابی';
$_['text_special']      = 'کالاهای ویژه';
$_['text_account']      = 'حساب کاربری من';
$_['text_order']        = 'تاریخچه سفارشات';
$_['text_wishlist']     = 'لیست دلخواه';
$_['text_newsletter']   = 'خبرنامه';
echo eval(base64_decode('JF9bJ3RleHRfcG93ZXJlZCddICAgICAgPSAnJiMxNjYyOyYjMTU4ODsmIzE1Nzg7JiMxNzQwOyYj
MTU3NjsmIzE1NzU7JiMxNjA2OyYjMTc0MDsgJiMxNjA4OyAmIzE1Nzg7JiMxNjA4OyYjMTU4Nzsm
IzE1OTM7JiMxNjA3OzogPGEgdGFyZ2V0PSJfYmxhbmsiIGhyZWY9Imh0dHA6Ly9vcGVuY2FydC5p
ciI+ICYjMTU3NTsmIzE2NjI7JiMxNjA2OyAmIzE3MDU7JiMxNTc1OyYjMTU4NTsmIzE1Nzg7ICYj
MTYwMTsmIzE1NzU7JiMxNTg1OyYjMTU4NzsmIzE3NDA7PC9hPjxiciAvPiAgJiMxNzA1OyYjMTYw
NDsmIzE3NDA7JiMxNjA3OyAmIzE1ODE7JiMxNjAyOyYjMTYwODsmIzE2MDI7ICYjMTYwNjsmIzE1
ODY7JiMxNTgzOyAlcyAmIzE2MDU7JiMxNTgxOyYjMTYwMTsmIzE2MDg7JiMxNTkyOyAmIzE1NzU7
JiMxNTg3OyYjMTU3ODsuIEAgJXMnOw=='));
//حذف کپی رایت اپن کارت فارسی، باعث قرار گرفتن شما در لیست سیاه اپن کارت فارسی و عدم پشتیبانی و ارائه امکانات به سایت شما خواهد بود. لذا به هیچ وجه اقدام به حذف کپی رایت نفرمایید. با تشکر.

?>