<?php
// Text
$_['text_home']     = 'خانه';
$_['text_wishlist'] = 'لیست دلخواه (%s)';
$_['text_shopping_cart'] = 'سبد خرید';
$_['text_search']   = 'جستجو';
$_['text_welcome']  = 'به فروشگاه ما خوش آمدید  هم اکنون می توانید <a href="%s">وارد حساب خود شوید</a> و یا <a href="%s">حساب جدید باز نمایید</a>.';
$_['text_logged']   = 'شما به عنوان <a href="%s">%s</a> وارد شده اید <b>(</b> <a href="%s">خروج</a> <b>)</b>';
$_['text_account']  = 'حساب کاربری من';
$_['text_checkout'] = 'تسویه حساب';
?>
