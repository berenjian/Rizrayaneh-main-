<?php
// Heading
$_['heading_title']     = 'در دست تعمیر است';

// Text
$_['text_maintenance']  = 'تعمیرات';
$_['text_message']      = '<h1 style="text-align:center;">در حال حاضر در حال تعمیرات هستیم. <br/>به زودی بر می گردیم .</h1>';
?>