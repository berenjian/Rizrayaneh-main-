<?php
// Heading 
$_['heading_title']   = 'دانلودها';

// Text
$_['text_account']    = 'حساب';
$_['text_downloads']  = 'دانلودها';
$_['text_order']      = 'کد سفارش:';
$_['text_date_added'] = 'تاریخ افزودن:';
$_['text_name']       = 'نام:';
$_['text_remaining']  = 'باقی مانده:';
$_['text_size']       = 'سایز:';
$_['text_empty']      = 'شما هیچ سفارش قابل دانلودی ندارید';
?>