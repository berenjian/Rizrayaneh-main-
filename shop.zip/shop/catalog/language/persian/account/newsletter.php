<?php
// Heading 
$_['heading_title']    = 'اشتراک خبرنامه';

// Text
$_['text_account']     = 'حساب کاربری';
$_['text_newsletter']  = 'خبرنامه';
$_['text_success']     = 'نتیجه : اشتراک خبرنامه با موفقیت به روزرسانی شد!';

// Entry
$_['entry_newsletter'] = 'اشتراک:';
?>
