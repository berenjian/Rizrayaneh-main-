<?php
// Heading 
$_['heading_title']      = 'تراکنش های شما';

// Column
$_['column_date_added']  = 'تاریخ اضافه شدن';
$_['column_description'] = 'توضیحات';
$_['column_amount']      = 'مقدار (%s)';

// Text
$_['text_account']       = 'حساب';
$_['text_transaction']   = 'تراکنش های شما';
$_['text_total']         = 'موجودی شما:';
$_['text_empty']         = 'شما هیچ تراکنش مالی نداشته اید!';
?>