<?php
// Heading 
$_['heading_title']  = 'پشتیبانی آنلاین یاهو';
?>