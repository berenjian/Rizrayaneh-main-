<?php
// Heading
$_['heading_title'] = 'دسته بندی ها';
?>