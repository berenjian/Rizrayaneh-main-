<?php
// Heading 
$_['heading_title'] = 'برجسته ترین ها';

// Text
$_['text_reviews']  = 'بر اساس %s نظر.'; 
?>