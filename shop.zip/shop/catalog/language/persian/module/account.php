<?php
// Heading 
$_['heading_title']    = 'حساب';

// Text
$_['text_register']    = 'ثبت نام';
$_['text_login']       = 'ورود';
$_['text_logout']      = 'خروج';
$_['text_forgotten']   = 'فراموشی رمز عبور';
$_['text_account']     = 'حساب کاربری من';
$_['text_edit']        = 'ویرایش حساب';
$_['text_password']    = 'رمز عبور';
$_['text_address']     = 'دفترچه های آدرس';
$_['text_wishlist']    = 'لیست دلخواه';
$_['text_order']       = 'تاریخچه سفارشات';
$_['text_download']    = 'دانلود ها';
$_['text_return']      = 'بازگرداندن';
$_['text_transaction'] = 'تراکنش ها';
$_['text_newsletter']  = 'خبرنامه';
$_['text_recurring']   = 'تکرار دوره ی پرداخت ها';
?>
