<?php
// Heading
$_['heading_title']	= 'آمار بازدید';

// Texts
$_['text_today']	= 'امروز';
$_['text_week']		= 'این هفته';
$_['text_month']	= 'این ماه';
$_['text_year']		= 'امسال';
$_['text_all']		= 'مجموع';
$_['text_online']	= 'افراد آنلاین';
$_['text_empty']	= '';