<?php
// Heading 
$_['heading_title']    = 'بازاریاب';

// Text
$_['text_register']    = 'ثبت نام';
$_['text_login']       = 'ورود';
$_['text_logout']      = 'خروج';
$_['text_forgotten']   = 'فراموشی رمز عبور';
$_['text_account']     = 'حساب کاربری من';
$_['text_edit']        = 'ویرایش حساب';
$_['text_password']    = 'رمز عبور';
$_['text_payment']     = 'گزینه های پرداخت';
$_['text_tracking']    = 'رهگیری بازاریابی';
$_['text_transaction'] = 'تراکنش ها';
?>
