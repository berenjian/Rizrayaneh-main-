<?php
// Text
$_['text_title']  = 'حمل بین شهری';
$_['text_weight'] = 'وزن:';
?>