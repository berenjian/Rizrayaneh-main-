<?php
// Text
$_['text_title']       = 'پیک فروشگاه';
$_['text_description'] = 'ارسال توسط پیک فروشگاه';
?>