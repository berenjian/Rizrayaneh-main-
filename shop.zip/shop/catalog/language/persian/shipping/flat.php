<?php
// Text
$_['text_title']       = 'پست پيشتاز';
$_['text_description'] = 'هزینه پست پيشتاز';
?>