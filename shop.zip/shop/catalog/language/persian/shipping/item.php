<?php
// Text
$_['text_title']       = 'حمل براساس هر آیتم';
$_['text_description'] = 'نرخ حمل هر آیتم';
?>