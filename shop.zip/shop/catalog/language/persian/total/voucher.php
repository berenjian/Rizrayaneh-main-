<?php
// Text
$_['text_voucher']  = 'کارت (%s)';
?>