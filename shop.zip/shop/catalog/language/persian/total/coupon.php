<?php
// Text
$_['text_coupon']   = 'کوپن (%s)';
?>