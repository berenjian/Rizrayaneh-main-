<?php
// Text
$_['text_reward']   = 'امتیاز جایزه(%s):';
$_['text_order_id'] = 'کد سفارش: #%s';
?>