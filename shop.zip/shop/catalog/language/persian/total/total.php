<?php
$_['text_total'] = 'جمع';
?>