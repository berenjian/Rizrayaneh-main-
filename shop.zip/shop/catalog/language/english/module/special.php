<?php
// Heading 
$_['heading_title'] = 'Specials';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>