<?php
// Heading 
$_['heading_title'] = 'Bestsellers';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>