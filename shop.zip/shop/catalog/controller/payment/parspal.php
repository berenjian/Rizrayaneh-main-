<?php
//require_once(DIR_SYSTEM.'library/nuSoap/nusoap.php');
class ControllerPaymentParspal extends Controller {
	protected function index() {
		$this->language->load('payment/parspal');
    	$this->data['button_confirm'] = $this->language->get('button_confirm');
		
		$this->data['text_wait'] = $this->language->get('text_wait');
		$this->data['text_ersal'] = $this->language->get('text_ersal');
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/parspal.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/payment/parspal.tpl';
		} else {
			$this->template = 'default/template/payment/parspal.tpl';
		}
		
		$this->render();		
}
public function confirm() {
		
		$this->load->model('checkout/order');
		
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		$this->load->library('encryption');
		
		$encryption = new Encryption($this->config->get('config_encryption'));
		
		//$this->data['Amount'] = $this->currency->format($order_info['total'], 'TMN', $order_info['value'], FALSE);
		
		
		$this->data['Amount'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
		
		//$this->data['Amount']=$this->data['Amount']\10;
	
		
		$this->data['PIN']=$this->config->get('parspal_PIN');
			$this->data['PASS']=$this->config->get('parspal_PASS');
		
		
		$this->data['ResNum'] = $this->session->data['order_id'];

		$this->data['return'] = $this->url->link('checkout/success', '', 'SSL');
		//$this->data['return'] = HTTPS_SERVER . 'index.php?route=checkout/success';
		
		$this->data['cancel_return'] = $this->url->link('checkout/payment', '', 'SSL');
		//$this->data['cancel_return'] = HTTPS_SERVER . 'index.php?route=checkout/payment';

		$this->data['back'] = $this->url->link('checkout/payment', '', 'SSL');
		
		//$client = new SoapClient("https://www.parspal.com/WebserviceGateway/wsdl");
		// $client = new nusoap_client('http://merchant.parspal.com/WebService.asmx?wsdl', true);	
		
	   // if((!$client)){
		//$json = array();
		//$json['error']= "Can not connect to PARSPal.<br>";	
	
		//$this->response->setOutput(json_encode($json));
		//}
		$amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);		//echo $this->data['Amount'];
			//$amount = intval($Amount) /$order_info['currency_value'];
			if($this->currency->getCode()=='RLS') {
		$amount=$amount / 10;
	}
	
		$this->load->model('checkout/order');
		
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
	
		//$ResNumber = 1234 ;// Order Id In Your System
	$Description = $order_info['comment'];
	$Paymenter =  $order_info['firstname'] .' ' . $order_info['lastname'];
	$Email = $order_info['email'];
	$Mobile =  $order_info['telephone'];
	
		//$callbackUrl = $this->url->https('payment/parspal/callback&order_id=' . $encryption->encrypt($this->session->data['order_id']));
		//$callbackUrl = HTTPS_SERVER . 'index.php?route=payment/parspal/callback&order_id=' . $encryption->encrypt($this->session->data['order_id']);
		$this->data['order_id'] = $encryption->encrypt($this->session->data['order_id']);
		//$callbackUrl = $this->url->link('payment/parspal/callback&order_id=' . $encryption->encrypt($this->session->data['order_id']));
		$callbackUrl  =  $this->url->link('payment/parspal/callback', 'order_id=' . $this->data['order_id'], 'SSL');
		
		//$res=$client->PaymentRequest($this->data['PIN'], $amount, $callbackUrl, urlencode(' خريد شماره: '.$order_info['order_id']) );
		
	$client = new SoapClient('http://merchant.parspal.com/WebService.asmx?wsdl');

	$res = $client->RequestPayment(array("MerchantID" => $this->data['PIN'] , "Password" =>	$this->data['PASS'], "Price" =>$amount, "ReturnPath" =>$callbackUrl, "ResNumber" =>$order_info['order_id'], "Description" =>$Description, "Paymenter" =>$Paymenter, "Email" =>$Email, "Mobile" =>$Mobile));

	$PayPath = $res->RequestPaymentResult->PaymentPath;
	$Status = $res->RequestPaymentResult->ResultStatus;
	
	if($Status == 'Succeed')
	{

		$this->data['action'] = $PayPath;
		$json = array();
		$json['success']= $this->data['action'];	
	
		$this->response->setOutput(json_encode($json));
		
		} else {
			
			$this->CheckState($Status);
			//die();
		}

//
		
	
		
}

	public function CheckState($status) {
		$json = array();
		$json['error']= $status;
		$this->response->setOutput(json_encode($json));

	
	}	
			
		
	


function verify_payment($authority, $amount){

	if($authority){
		//$client = new SoapClient("http://www.parspal.com/WebserviceGateway/wsdl");
		 $client = new nusoap_client('https://www.parspal.com/WebserviceGateway/wsdl', true);	
		if ((!$client))
			{echo  "Error: can not connect to parspal.<br>";return false;}
		
		else {
			$this->data['PIN'] = $this->config->get('parspal_PIN');
			//$res = $client->PaymentVerification($this->data['PIN'], $authority ,$amount);
			$parameters = array(
			$this->data['PIN'],
			$authority,
			$amount);
		$res = $client->call('PaymentVerification', $parameters);
		
			$this->CheckState($res);
			
			if($res==1)
				return true;

			else {
				return false;
			}
		
		}
	} 
	
	else {
		return false;
	}
	
	
	return false;
}

	public function callback() {
		$this->load->library('encryption');

		$encryption = new Encryption($this->config->get('config_encryption'));
		
		//$order_id = $encryption->decrypt($this->request->get['order_id']);
		$MerchantID=$this->config->get('parspal_PIN');
		$Password=$this->config->get('parspal_PASS');
	    if(true || isset($_POST['status']) && $_POST['status'] == 100){
		$Status = $_POST['status'];

		$Refnumber = $_POST['refnumber'];

		$Resnumber = $_POST['resnumber'];
//Your Order ID
          $order_id=$this->session->data['order_id'];
        $this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($order_id);
	$amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);		//echo $this->data['Amount'];
			//$amount = intval($Amount) /$order_info['currency_value'];
			if($this->currency->getCode()=='RLS') {
		$amount=$amount / 10;
	
			}
		$client = new SoapClient('http://merchant.parspal.com/WebService.asmx?wsdl');

		$res = $client->VerifyPayment(array("MerchantID" => $MerchantID , "Password" =>$Password , "Price" =>$amount,"RefNum" =>$Refnumber ));
		
		//$Amount = $this->currency->format($order_info['total'], 'RLS', $order_info['value'], FALSE);
		
		
		
			
		$Status = $res->verifyPaymentResult->ResultStatus;
		$PayPrice = $res->verifyPaymentResult->PayementedPrice;
		if($Status == 'success')// Your Peyment Code Only This Event
		{
				$this->model_checkout_order->confirm($order_id, $this->config->get('parspal_order_status_id'),'شماره رسيد ديجيتالي; Refnumber: '.$Refnumber);
				
				$this->response->setOutput('<html><head><meta http-equiv="refresh" CONTENT="2; url=' . $this->url->link('checkout/success') . '"></head><body><table border="0" width="100%"><tr><td>&nbsp;</td><td style="border: 1px solid gray; font-family: tahoma;background: #EDEBFE; font-size: 14px; direction: rtl; text-align: right;">با تشکر پرداخت تکمیل شد.لطفا چند لحظه صبر کنید و یا  <a href="' . $this->url->link('checkout/success') . '"><b>اینجا کلیک نمایید</b></a></td><td>&nbsp;</td></tr><tr><td colspan="2"> شماره رسيد ديجيتالي:'.$Refnumber.'</td></tr></table></body></html>');
			}
		else {
			$this->response->setOutput('<html><body><table border="0" width="100%"><tr><td>&nbsp;</td><td style="border: 1px solid gray;background: #EDEBFE; font-family: tahoma; font-size: 14px; direction: rtl; text-align: right;">خطا در عملیات پردازش پرداخت:<br />کد خطا:'.$Status.'<br /><br /><a href="' . $this->url->link('checkout/cart').  '"><b>بازگشت به فروشگاه</b></a></td><td>&nbsp;</td></tr></table></body></html>');
		}
	}
		 else {
			$this->response->setOutput('<html><body><table border="0" width="100%"><tr><td>&nbsp;</td><td style="border: 1px solid gray;background: #EDEBFE; font-family: tahoma; font-size: 14px; direction: rtl; text-align: right;">.		بازگشت از عمليات پرداخت، خطا در انجام عملیات پرداخت ( پرداخت ناموق ) !<br /><br /><a href="' . $this->url->link('checkout/cart').  '"><b>بازگشت به فروشگاه</b></a></td><td>&nbsp;</td></tr></table></body></html>');
		}
	}
	
}
?>