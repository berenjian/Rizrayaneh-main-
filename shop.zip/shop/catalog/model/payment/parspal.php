<?php 
class ModelPaymentParspal extends Model {
  	public function getMethod() {
		$this->load->language('payment/parspal');

		if ($this->config->get('parspal_status')) {
      		  	$status = TRUE;
      	} else {
			$status = FALSE;
		}
		
		$method_data = array();
	
		if ($status) {  
      		$method_data = array( 
        		'code'         => 'parspal',
        		'title'      => $this->language->get('text_title'),
				'sort_order' => $this->config->get('parspal_sort_order')
      		);
    	}
   
    	return $method_data;
  	}
}
?>